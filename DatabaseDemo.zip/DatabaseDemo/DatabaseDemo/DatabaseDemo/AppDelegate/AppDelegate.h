//
//  AppDelegate.h
//  DatabaseDemo
//
//  Created by miao on 2019/5/7.
//  Copyright © 2019年 miao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

