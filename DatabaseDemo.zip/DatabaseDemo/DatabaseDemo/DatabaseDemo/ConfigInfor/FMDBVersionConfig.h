//
//  FMDBVersionConfig.h
//  DatabaseDemo
//
//  Created by miao on 2019/5/15.
//  Copyright © 2019年 miao. All rights reserved.
//


//当前版本
#define FMDBReleaseCurrentVersion                                               @"2.0"
