//
//  FMDBAppUpgradeManager.h
//  DatabaseDemo
//
//  Created by miao on 2019/5/15.
//  Copyright © 2019年 miao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDBAppUpgradeManagerInterface.h"

NS_ASSUME_NONNULL_BEGIN

@interface FMDBAppUpgradeManager : NSObject<FMDBAppUpgradeManagerInterface>

@end

NS_ASSUME_NONNULL_END
