//
//  FMDBBackgroundRunModule.h
//  DatabaseDemo
//
//  Created by miao on 2019/5/21.
//  Copyright © 2019年 miao. All rights reserved.
//

#import "FMDBDBModule.h"

NS_ASSUME_NONNULL_BEGIN

@interface FMDBBackgroundRunModule : FMDBDBModule

@end

NS_ASSUME_NONNULL_END
