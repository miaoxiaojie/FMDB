//
//  FMDBDBModule.h
//  DatabaseDemo
//
//  Created by miao on 2019/5/14.
//  Copyright © 2019年 miao. All rights reserved.
//

#import "FMDBStartBaseModule.h"

NS_ASSUME_NONNULL_BEGIN

@interface FMDBDBModule : FMDBStartBaseModule

@end

NS_ASSUME_NONNULL_END
